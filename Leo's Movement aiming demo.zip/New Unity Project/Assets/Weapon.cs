﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Weapon : MonoBehaviour
{
    public float bulletsize = 1F;
    public float ChargeTimer = 0;
    public Transform firePoint;
    public GameObject bulletPreFab;

        // Update is called once per frame
        void Update()
        {
            if (Input.GetButtonDown("Fire1"))
            {
                Shoot();
            }
        }

    /*   void Update()
       {
           if (Input.GetKey("Fire1"))
           {
               ChargeTimer += Time.deltaTime;
           }
           if ((Input.GetKeyUp("Fire1")) && (ChargeTimer > 2))
           {
               Shoot();
           }
       }*/

    void Shoot()
    {
       // bulletPreFab.transform.localScale = new Vector3(ChargeTimer * bulletsize, ChargeTimer * bulletsize );

        Instantiate(bulletPreFab, firePoint.position, firePoint.rotation);
    }
}
